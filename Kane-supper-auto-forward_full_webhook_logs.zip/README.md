# Kane-supper-auto-forward

This bot auto-forwards Telegram messages based on keywords, stickers, etc. Includes a Flask UI and Telegram admin control.
